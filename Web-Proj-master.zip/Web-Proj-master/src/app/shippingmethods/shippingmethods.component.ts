import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shippingmethods',
  templateUrl: './shippingmethods.component.html',
  styleUrls: ['./shippingmethods.component.css']
})
export class ShippingmethodsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
