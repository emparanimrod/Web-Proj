import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vouchers',
  templateUrl: './vouchers.component.html',
  styleUrls: ['./vouchers.component.css']
})
export class VouchersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
