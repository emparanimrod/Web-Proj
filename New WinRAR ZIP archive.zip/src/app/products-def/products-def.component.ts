import { Component, OnInit } from '@angular/core';
import * as WC from 'woocommerce-api';
import {NgbCarouselConfig} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-products-def',
  templateUrl: './products-def.component.html',
  styleUrls: ['./products-def.component.css'],
  providers: [NgbCarouselConfig]
})
export class ProductsDefComponent implements OnInit {

  WooCommerce: any; 
  products: any[];

  
  constructor(config: NgbCarouselConfig) { 

    //carousel
    // config.wrap = true;

    this.WooCommerce = WC({
      url: 'https://cloud.edgetech.co.ke/m-tush',
      consumerKey: 'ck_3106173da4bf0f0269cd58e8be438139dc515b87',
      consumerSecret: 'cs_ee6a004c51a4206d4d9a374b1b05adac24927f53',
      version: 'v3',
      // wpAPI: false,
      // version: 'wc/v1',
      verifySsl: false,
      queryStringAuth: true
    });

    this.WooCommerce.getAsync('products').then( (data) => {
      console.log(JSON.parse(data.body));
      this.products = JSON.parse(data.body).products;
     }, (err) =>{
      console.log(err)
     });

  }

  ngOnInit() {
  }

}
